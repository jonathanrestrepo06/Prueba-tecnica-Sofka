/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sofka;

/**
 *
 * @author jonat
 */
public abstract class Nave {
    private String tipo;
    private int anio;
    private String pais;
    private String nombre;
    private double peso;
    private double tamaño;
    private double velocidad;

    public Nave(String tipo, int anio, String pais, String nombre, double peso, double tamaño, double velocidad) {
        this.tipo = tipo;
        this.anio = anio;
        this.pais = pais;
        this.nombre = nombre;
        this.peso = peso;
        this.tamaño = tamaño;
        this.velocidad = velocidad;
    }
    
    public abstract String info();
    
    public abstract double capacidadDeCarga();
    
    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public int getAnio() {
        return anio;
    }

    public void setAnio(int anio) {
        this.anio = anio;
    }

    public String getPais() {
        return pais;
    }

    public void setPais(String pais) {
        this.pais = pais;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public double getTamaño() {
        return tamaño;
    }

    public void setTamaño(double tamaño) {
        this.tamaño = tamaño;
    }

    public double getVelocidad() {
        return velocidad;
    }

    public void setVelocidad(double velocidad) {
        this.velocidad = velocidad;
    }
    
    
    
}
