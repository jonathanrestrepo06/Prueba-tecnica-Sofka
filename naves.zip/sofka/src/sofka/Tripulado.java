/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sofka;

/**
 *
 * @author jonat
 */
public class Tripulado extends Nave{

    public Tripulado(String tipo, int anio, String pais, String nombre, double peso, double tamaño, double velocidad) {
        super(tipo, anio, pais, nombre, peso, tamaño, velocidad);
    }
    @Override
    public String info(){
    
        String info = "La nave tripulada "+super.getNombre() +" fue creada en el año "+ 
                super.getAnio()+ " en " + super.getPais()+ " . Tiene un tamaño de " 
                + super.getTamaño() + " un peso de " + super.getPeso()
                + " y una velocidad final de " + super.getVelocidad();
        return info;
    
    }
    @Override
    public double capacidadDeCarga(){
        return super.getTamaño()*super.getVelocidad();
    }
}
